# ONEXIO CONTROL CENTER V8 — bêta

## Fichiers
- `index.html` : prototype principal.
- `manifest.webmanifest` : métadonnées PWA.
- `sw.js` : cache hors ligne de base.
- `icon.svg` : icône.

## Publication GitHub Pages
1. Ouvre ton dépôt GitHub `Onexio panel`.
2. Conserve une copie de la version actuelle avant modification.
3. Téléverse les quatre fichiers à la racine du dépôt (ou dans le dossier publié par Pages).
4. Dans Settings → Pages, vérifie la branche et le dossier publiés.
5. Attends la publication, puis ouvre l'adresse GitHub Pages sur ton téléphone.

## Limites de cette bêta
- Ce prototype ne se connecte pas à Free Fire ou Call of Duty Mobile.
- Il ne modifie aucun réglage du jeu et n'exécute aucune macro.
- Les valeurs de sensibilité ne sont pas encore générées : l'écran affiche un message de démonstration.
- Aucun serveur ni collecte centralisée n'est installé.
- Les informations et avis restent dans le stockage local du navigateur. L'utilisateur peut exporter ses avis en JSON et les transmettre volontairement.
- La détection automatique du modèle exact n'est pas garantie par un navigateur web ; la saisie manuelle reste disponible.

## Confidentialité
Ne demandez pas d'identifiants de jeu, de mots de passe, de coordonnées ou d'autres données personnelles dans les avis de bêta.
